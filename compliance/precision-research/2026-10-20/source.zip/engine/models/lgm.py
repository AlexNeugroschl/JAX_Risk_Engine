"""
One-factor Linear Gauss-Markov (LGM) model, in ORE's state-variable parametrization.

This is the model behind ORE's `NumericLgmMultiLegOptionEngine` and the model
`engine.pricing.lgm_grid` rolls back on. Formulas follow `QuantExt::Lgm1fParametrization` and
`LinearGaussMarkovModel` (QuantExt/qle/models/lgm.hpp):

    H(t)      = (1 - exp(-a*t)) / a
    zeta(t)   = integral_0^t sigma(s)^2 ds
    P(t,T,x)  = [P(0,T)/P(0,t)] * exp(-0.5*(H(T)^2-H(t)^2)*zeta(t) - (H(T)-H(t))*x)
    N(t,x)    = exp(0.5*H(t)^2*zeta(t) + H(t)*x) / P(0,t)       (numeraire)
    r(t,x)    = f(0,t) + x*H'(t) + zeta(t)*H'(t)*H(t)

The state x(t) is driftless (`IrLgm1fStateProcess::expectation` returns its input), with
variance zeta(t).

Not the same model as `engine.models.hull_white` for the same `(a, sigma)`. Here sigma is
the volatility of x, so the equivalent Hull-White short-rate volatility is
`sigma * exp(-a*t)`; `QuantLib::HullWhite` uses a constant `sigma`. The two agree at t=0 and
diverge after. Bermudan/American pricing uses only this module, as ORE does.

`Sigma` is piecewise constant (`Lgm1fPiecewiseConstantParametrization`); a flat sigma is
the one-bucket case. Only zeta depends on sigma; H depends only on the reversion `a`.

`bond_option_sigma` is the LGM zero-bond option volatility. It is fed to the model-free
Black-on-bond formula in `hull_white.bond_call`/`bond_put`, which `engine.calibration`
uses to price co-terminal Europeans as `AnalyticLgmSwaptionEngine` does.

`shift` is ORE's `Lgm1fParametrization::shift()`: every formula reads `H(t) + shift` for `H(t)`.
It is an exact invariance of the model (bond prices are unchanged when the state moves to
`x - shift * zeta(t)`, and the numeraire's measure moves with it), so it changes no price in the
limit, only where a discretization centres its state: the grid engine's state grid is centred on
the shifted state. ORE's `LgmBuilder` sets `shift = -H(horizon)` (`horizon_shift`), so `H + shift`
vanishes at the horizon; 0, the default, is the unshifted model. The cross-asset model's LGM is
never shifted (ORE refuses a shift horizon there).

The Hull-White model is the same LGM with another volatility parametrization, ORE's
`Lgm1fPiecewiseConstantHullWhiteAdaptor` (QuantExt/qle/models/
irlgm1fpiecewiseconstanthullwhiteadaptor.hpp, `ReversionType = VolatilityType = HullWhite`):
sigma is the short rate's piecewise-constant volatility, H is unchanged and

    alpha(t) = sigma(t) exp(a t),   zeta(t) = integral_0^t sigma(s)^2 exp(2 a s) ds
                                               (`hull_white_zeta`).

Every LGM formula above holds for it with that zeta: bond prices, the numeraire and the
driftless state. `hull_white_matching_zeta` converts a Hagan volatility into the Hull-White
one with the same zeta at chosen times, which is how a Hull-White component is calibrated.
"""
from dataclasses import dataclass
from typing import Union

import jax
import jax.numpy as jnp
import numpy as np

from engine.market_data.curves import ZeroCurve, discount, forward_rate

#: ORE's `LgmData::VolatilityType`: the LGM's own volatility (alpha, `Hagan`) or the short
#: rate's (`HullWhite`, the Hull-White adaptor).
VOLATILITY_TYPES = ("Hagan", "HullWhite")


@jax.tree_util.register_pytree_node_class
@dataclass
class Sigma:
    """Piecewise-constant volatility: `sigma(s) = values[i]` on bucket `i`.

    Buckets are `[0, times[0]), [times[0], times[1]), ..., [times[-1], inf)`, as ORE's
    `alphaTimes`/`alpha`, so `len(values) == len(times) + 1`. Empty `times` means flat.

    Registered as a pytree with both fields as children, so tangents propagate when a
    `Sigma` is nested inside a larger argument (a model's `(a, sigma)`). As an unregistered
    leaf it would silently get a zero tangent.
    """
    times: jax.Array    # [B-1], strictly increasing, B = number of buckets
    values: jax.Array   # [B]

    @staticmethod
    def flat(sigma: float, dtype=jnp.float64) -> "Sigma":
        # Reshape rather than `jnp.asarray([sigma])`: a Python list around a tracer
        # fails under jit/grad ("No constant handler for type: DynamicJaxprTracer").
        return Sigma(
            times=jnp.zeros((0,), dtype=dtype),
            values=jnp.reshape(jnp.asarray(sigma, dtype=dtype), (1,)),
        )

    def astype(self, dtype) -> "Sigma":
        """The same volatility with times and values in `dtype`."""
        return Sigma(times=jnp.asarray(self.times, dtype=dtype), values=jnp.asarray(self.values, dtype=dtype))

    def tree_flatten(self):
        return (self.times, self.values), None

    @classmethod
    def tree_unflatten(cls, aux_data, children):
        times, values = children
        return cls(times=times, values=values)


def as_sigma(sigma: Union[float, jax.Array, "Sigma"]) -> Sigma:
    """Wrap a scalar sigma as a one-bucket `Sigma`; pass a `Sigma` through."""
    if isinstance(sigma, Sigma):
        return sigma
    return Sigma.flat(sigma)


def zeta(sigma: Union[float, jax.Array, "Sigma"], t: jax.Array) -> jax.Array:
    """
    zeta(t) = integral_0^t sigma(s)^2 ds, the variance of x(t).

    `sigma^2 * t` when flat; otherwise the sum of whole buckets plus the partial bucket
    containing `t`, as `QuantExt::PiecewiseConstantHelper1::int_y_sqr`. Bucket lookup
    uses `searchsorted(side="right")`, matching ORE's `std::upper_bound`.
    """
    s = as_sigma(sigma)
    t = jnp.maximum(t, 0.0)
    if s.times.shape[0] == 0:
        return (s.values[0] ** 2) * t

    boundaries = jnp.concatenate([jnp.zeros((1,), dtype=s.times.dtype), s.times])  # [B], left edge of each bucket
    full_durations = s.times - boundaries[:-1]              # [B-1], duration of every bucket EXCEPT the last (open-ended) one
    full_contrib = s.values[:-1] ** 2 * full_durations       # [B-1]
    cum_before = jnp.concatenate([jnp.zeros((1,), dtype=full_contrib.dtype), jnp.cumsum(full_contrib)])  # [B]

    i = jnp.clip(jnp.searchsorted(s.times, t, side="right"), 0, s.values.shape[0] - 1)
    bucket_start = jnp.where(i == 0, 0.0, boundaries[jnp.clip(i, 1, boundaries.shape[0] - 1)])
    partial = s.values[i] ** 2 * jnp.maximum(t - bucket_start, 0.0)
    return cum_before[i] + partial


def _exp_integral(rate, lo, hi):
    """integral_lo^hi exp(rate s) ds = exp(rate lo) (hi - lo) expm1(x)/x, x = rate (hi - lo);
    (hi - lo) when rate is 0. Branch-safe under jit/grad."""
    width = hi - lo
    x = rate * width
    x_safe = jnp.where(x == 0.0, 1.0, x)
    ratio = jnp.where(x == 0.0, 1.0, jnp.expm1(x_safe) / x_safe)
    return jnp.exp(rate * lo) * width * ratio


def hull_white_zeta(a: float, sigma: Union[float, jax.Array, "Sigma"], t: jax.Array) -> jax.Array:
    """zeta(t) = integral_0^t sigma(s)^2 exp(2 a s) ds of the Hull-White adaptor (see the
    module docstring), as `PiecewiseConstantHelper3::int_y1_sqr_exp_2_int_y2` with a constant
    reversion; `sigma^2 t` at a = 0, where the adaptor is the Hagan LGM."""
    s = as_sigma(sigma)
    t = jnp.maximum(jnp.asarray(t), 0.0)
    edges = jnp.concatenate([jnp.zeros((1,), dtype=s.times.dtype), s.times])        # [B] left edges
    ends = jnp.concatenate([s.times, jnp.full((1,), jnp.inf, dtype=s.times.dtype)])  # [B] right edges
    hi = jnp.clip(t[..., None], edges, ends)
    return jnp.sum(s.values ** 2 * _exp_integral(2.0 * a, edges, hi), axis=-1)


def hull_white_matching_zeta(a: float, hagan: "Sigma", last: float) -> "Sigma":
    """The Hull-White volatility on the buckets of a bootstrapped Hagan volatility whose zeta
    equals the Hagan LGM's at every bucket end: the bucket times, and `last` (after them) for
    the open last bucket. `calibrateVolatilitiesIterative` lays the buckets out so: bucket i
    ends at helper i's expiry, and `last` is the last helper's. Bucket by bucket, with
    m_{-1} = 0 and m_i the ends,

        sigma_HW,i^2 = sigma_i^2 (m_i - m_{i-1}) / integral_{m_{i-1}}^{m_i} exp(2 a s) ds.

    A helper's model price depends on the volatility only through zeta at its expiry and on
    H, which the two parametrizations share, so the converted volatility reprices every
    helper exactly as the Hagan one: it is the Hull-White bootstrap. Values keep `hagan`'s
    batch axes (one calibration per path)."""
    times = np.asarray(hagan.times, dtype=np.float64)
    ends = np.concatenate([times, [float(last)]])
    starts = np.concatenate([[0.0], times])
    if np.any(ends <= starts):
        raise ValueError(f"bucket ends must increase from 0 and `last` follow the bucket times; got {ends.tolist()}")
    weight = _exp_integral(2.0 * a, jnp.asarray(starts), jnp.asarray(ends))
    scale = jnp.sqrt(jnp.asarray(ends - starts) / weight)
    return Sigma(times=jnp.asarray(times), values=jnp.asarray(hagan.values) * scale)


def H(a: float, t: jax.Array, shift=0.0) -> jax.Array:
    """H(t) = (1-exp(-a*t))/a + shift, with the a -> 0 limit H(t) = t + shift
    (`Lgm1fParametrization::H`, its `shift_` added to the parametrization's own)."""
    t = jnp.maximum(jnp.asarray(t), 0.0)
    x = a * t
    small = jnp.abs(x) < 1e-4
    # The series preserves both derivatives at zero reversion. A constant `where(a == 0)`
    # branch gives the right value but silently returns zero reversion sensitivities.
    series = 1.0 + x * (-0.5 + x * (1.0 / 6.0 + x * (-1.0 / 24.0 + x / 120.0)))
    safe = jnp.where(small, 1.0, x)
    return t * jnp.where(small, series, -jnp.expm1(-safe) / safe) + shift


def H_prime(a: float, t: jax.Array) -> jax.Array:
    """H'(t) = exp(-a*t)."""
    return jnp.exp(-a * t)


def horizon_shift(a: float, horizon: jax.Array) -> jax.Array:
    """The shift that makes H vanish at `horizon` (years, >= 0): `-H(horizon)`, as ORE's
    `LgmBuilder` sets it from `LgmData::shiftHorizon` (0 at horizon 0, the unshifted model)."""
    return -H(a, horizon)


def bond_price(curve: ZeroCurve, a: float, sigma: Union[float, Sigma], t: jax.Array, T: jax.Array, x: jax.Array,
               shift=0.0) -> jax.Array:
    """
    Zero-bond price P(t,T) at LGM state x:

        P(t,T,x) = [P(0,T)/P(0,t)] * exp(-0.5*(H(T)^2-H(t)^2)*zeta(t) - (H(T)-H(t))*x)

    with `H` shifted by `shift` (see the module docstring). Matches
    `ORE.LinearGaussMarkovModel.discountBond` to ~1e-16 relative.
    """
    P0T = discount(curve, T)
    P0t = jnp.where(t > 0.0, discount(curve, jnp.maximum(t, 1e-12)), 1.0)
    Ht, HT = H(a, t, shift), H(a, T, shift)
    return (P0T / P0t) * jnp.exp(-0.5 * (HT ** 2 - Ht ** 2) * zeta(sigma, t)) * jnp.exp(-(HT - Ht) * x)


def numeraire(curve: ZeroCurve, a: float, sigma: Union[float, Sigma], t: jax.Array, x: jax.Array,
              shift=0.0) -> jax.Array:
    """
    N(t,x) = exp(0.5*H(t)^2*zeta(t) + H(t)*x) / P(0,t), as
    `LinearGaussMarkovModel::numeraire`, with `H` shifted by `shift` (so N(0,x) = exp(shift*x)).
    The backward induction deflates by this, so the rolled-back quantity is a martingale under
    x's driftless law.
    """
    P0t = jnp.where(t > 0.0, discount(curve, jnp.maximum(t, 1e-12)), 1.0)
    Ht = H(a, t, shift)
    return jnp.exp(0.5 * Ht ** 2 * zeta(sigma, t) + Ht * x) / P0t


def r_from_x(curve: ZeroCurve, a: float, sigma: Union[float, Sigma], t: jax.Array, x: jax.Array,
             shift=0.0) -> jax.Array:
    """
    Short rate at LGM state x: r(t,x) = f(0,t) + x*H'(t) + zeta(t)*H'(t)*H(t),
    i.e. -d/dT log P(t,T,x) at T=t, with `H` shifted by `shift`.
    """
    f0t = forward_rate(curve, t)
    Hp = H_prime(a, t)
    return f0t + x * Hp + zeta(sigma, t) * Hp * H(a, t, shift)


def x_from_r(curve: ZeroCurve, a: float, sigma: Union[float, Sigma], t: jax.Array, r: jax.Array,
             shift=0.0) -> jax.Array:
    """Inverse of `r_from_x` (affine in x). Returns 0 at t <= 0."""
    f0t = forward_rate(curve, t)
    Hp = H_prime(a, t)
    x = (r - f0t - zeta(sigma, t) * Hp * H(a, t, shift)) / Hp
    return jnp.where(t > 0.0, x, jnp.zeros_like(r))


def bond_option_sigma(a: float, sigma: Union[float, Sigma], T_opt: jax.Array, S: jax.Array, t: jax.Array) -> jax.Array:
    """
    Volatility, seen from `t`, of the zero bond P(T_opt, S, x):

        |H(S) - H(T_opt)| * sqrt(zeta(T_opt) - zeta(t))

    Read off `bond_price`'s exponent, since ln P is affine in the Gaussian state x.
    """
    H_diff = H(a, S) - H(a, T_opt)
    variance = jnp.clip(zeta(sigma, T_opt) - zeta(sigma, t), 0.0, None)
    return jnp.abs(H_diff) * jnp.sqrt(variance)
