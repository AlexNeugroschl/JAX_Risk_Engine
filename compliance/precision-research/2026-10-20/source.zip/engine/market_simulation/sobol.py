"""
Quasi-Monte Carlo normals: scrambled Sobol points mapped to standard normals, and a Brownian
bridge over the simulation grid (QuantLib's `BrownianBridge` construction order).

Model-independent; shared by the cross-asset simulation (`engine.market_simulation.config.simulate`)
and the market-risk scenario generator (`engine.risk.market.scenarios`).
"""
from functools import partial
from dataclasses import replace

import jax
import jax.numpy as jnp
import numpy as np
from jax.scipy.stats import norm
from scipy.stats.qmc import Sobol

from engine.precision import Arithmetic


def generate_sobol_normals(num_scenarios: int, num_steps: int, num_assets: int, dtype, seed: int = 42,
                           replicates: int = 1) -> jax.Array:
    """
    Scrambled Sobol uniforms (CPU) mapped to standard normals `[TimeSteps, Scenarios,
    Assets]`.

    `seed` selects the Owen scrambling: the same seed reproduces the draw; different seeds
    are independent randomized-QMC replicates. With `replicates > 1`, concatenate independent
    scrambles derived from the seed; a paired run takes a prefix of EACH scramble. The output is cast to `dtype`, because
    `norm.ppf` computes in float64 whenever x64 is on.
    """
    from engine.precision.estimate import validate_replicates
    validate_replicates(num_scenarios, replicates, "replicates")
    total_dimensions = num_steps * num_assets

    # Scrambling randomizes the otherwise deterministic Sobol points.
    seeds = ([seed] if replicates == 1 else
             [int(s.generate_state(1)[0]) for s in np.random.SeedSequence(seed).spawn(replicates)])
    uniform_draws = np.concatenate([Sobol(d=total_dimensions, scramble=True, seed=s).random(n=num_scenarios // replicates)
                                    for s in seeds])

    # The JAX half is jitted: eagerly, each op compiled separately and dominated the
    # function's cost.
    return _sobol_uniforms_to_normals(uniform_draws, num_scenarios, num_steps, num_assets, dtype)


@partial(jax.jit, static_argnums=(1, 2, 3, 4))
def _sobol_uniforms_to_normals(uniform_draws, num_scenarios: int, num_steps: int, num_assets: int, dtype) -> jax.Array:
    """Clip the uniforms off {0, 1}, map through the inverse normal CDF, and reshape to
    `[TimeSteps, Scenarios, Assets]`. Everything but `uniform_draws` is static."""
    uniform_jax = jnp.asarray(uniform_draws, dtype=dtype)
    epsilon = jnp.finfo(dtype).eps
    uniform_clipped = jnp.clip(uniform_jax, epsilon, 1.0 - epsilon)

    normal_shocks = norm.ppf(uniform_clipped).astype(dtype)

    # [Scenarios, Steps, Assets] -> [Steps, Scenarios, Assets]
    Z = normal_shocks.reshape((num_scenarios, num_steps, num_assets))
    return jnp.transpose(Z, (1, 0, 2))

def _build_bridge_matrix(time_grid: np.ndarray) -> np.ndarray:
    """
    Brownian-bridge construction matrix B with W(t_1..t_n) = B @ Z, where Z are independent
    normals ordered by Sobol dimension (dimension 0 is the endpoint, 1 the midpoint, ...),
    by the recursive bisection of QuantLib's `BrownianBridge`.
    """
    times = np.asarray(time_grid, dtype=np.float64)[1:]  # drop t=0
    n = times.shape[0]
    B = np.zeros((n, n), dtype=np.float64)

    left_index = np.zeros(n, dtype=np.int64)
    right_index = np.zeros(n, dtype=np.int64)
    bridge_index = np.zeros(n, dtype=np.int64)
    left_weight = np.zeros(n, dtype=np.float64)
    right_weight = np.zeros(n, dtype=np.float64)
    std_dev = np.zeros(n, dtype=np.float64)

    # map_[k] != 0 marks slot k as already constructed; each iteration bisects the widest
    # remaining gap (as QuantLib's BrownianBridge).
    map_ = np.zeros(n, dtype=np.int64)
    map_[n - 1] = 1
    bridge_index[0] = n - 1
    std_dev[0] = np.sqrt(times[-1])

    for i in range(1, n):
        j = 0
        while map_[j] != 0:
            j += 1
        k = j
        while map_[k] == 0:
            k += 1
        # Midpoint between the known bounds j-1 and k.
        l = j + ((k - 1 - j) // 2)
        map_[l] = i

        left_index[i] = j
        right_index[i] = k
        bridge_index[i] = l

        left_t = times[j - 1] if j != 0 else 0.0
        right_t = times[k]
        mid_t = times[l]

        left_weight[i] = (right_t - mid_t) / (right_t - left_t)
        right_weight[i] = (mid_t - left_t) / (right_t - left_t)
        std_dev[i] = np.sqrt(
            (mid_t - left_t) * (right_t - mid_t) / (right_t - left_t)
        )

    # Turn the recursion into an explicit linear map from Z to W.
    B[n - 1, 0] = std_dev[0]
    for i in range(1, n):
        row = bridge_index[i]
        B[row, i] += std_dev[i]
        if left_index[i] != 0:
            B[row, :] += left_weight[i] * B[left_index[i] - 1, :]
        if right_index[i] != n:
            B[row, :] += right_weight[i] * B[right_index[i], :]

    return B


def bridge_increments_matrix(time_grid) -> np.ndarray:
    """`[T, T]`: the matrix A with `A @ Z` the bridged increments standardized by sqrt(dt),
    `dW_i / sqrt(dt_i)`: the bridge `B` (`_build_bridge_matrix`) differenced along time and
    scaled, on the host in float64. Folding the difference in keeps it out of the device's
    arithmetic: differencing the path values there would subtract numbers that grow as sqrt(t)
    to get increments that do not, a cancellation a format below float32 cannot afford (F-07)."""
    times = np.asarray(time_grid, dtype=np.float64)
    bridge = _build_bridge_matrix(times)
    increments = np.diff(np.concatenate([np.zeros((1, bridge.shape[1])), bridge]), axis=0)
    return increments / np.sqrt(np.diff(times))[:, None]


@jax.jit
def _apply_bridge_matrix(matrix: jax.Array, Z: jax.Array, arithmetic: Arithmetic) -> jax.Array:
    """`matrix @ Z` over the time axis of `Z` `[T, ...]`, as one `[T, T] x [T, rest]` product."""
    if arithmetic.key is not None:
        # Flattened columns are (sample, asset); retain a global column identity.
        ids = jnp.arange(Z.shape[1], dtype=jnp.uint32) if arithmetic.sample_ids is None else arithmetic.sample_ids
        ids = (ids[:, None] * Z.shape[2] + jnp.arange(Z.shape[2], dtype=jnp.uint32)).reshape(-1)
        arithmetic = replace(arithmetic, sample_ids=ids)
    return arithmetic.matmul(matrix, Z.reshape(Z.shape[0], -1), shared="left", sample_axis=1).reshape(Z.shape)


def apply_brownian_bridge(Z: jax.Array, time_grid, arithmetic: Arithmetic = None) -> jax.Array:
    """Independent normals `[TimeSteps, Scenarios, Assets]` -> bridged increments,
    standardized by sqrt(dt): one product with `bridge_increments_matrix`, in `arithmetic`
    (the normals' own format, float64 or float32, by default)."""
    arithmetic = arithmetic or Arithmetic.of(Z.dtype)
    return _apply_bridge_matrix(jnp.asarray(bridge_increments_matrix(np.asarray(time_grid))), Z, arithmetic)
