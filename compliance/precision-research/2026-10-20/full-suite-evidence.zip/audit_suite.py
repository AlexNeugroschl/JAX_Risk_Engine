"""Audit exact full-suite coverage across same-source passing partitions."""
import collections, hashlib, json, re
from pathlib import Path
import xml.etree.ElementTree as ET

root = Path.cwd()
b = root / '.profile-out-fp8-implementation'
def read(p):
    return json.loads(p.read_text(encoding='utf-8'))
manifest = read(b / 'final-universe.json')
digest = hashlib.sha256()
for folder in ('engine','tests','benchmarks','demos'):
    for path in sorted((root/folder).rglob('*.py')):
        digest.update(path.relative_to(root).as_posix().encode()+b'\0')
        digest.update(path.read_bytes().replace(b'\r\n',b'\n'))
assert digest.hexdigest() == manifest['source_digest'], 'Python sources changed during verification'
seen, counts, evidence = [], collections.Counter(), []
for name in ('final-fast','final-slow'):
    data = read(b/name/'suite.json')
    assert data['source_digest'] == manifest['source_digest']
    assert data['complete'], 'test partition not yet complete'
    for row in data['batches']:
        assert row['passes'] and row['exit_code'] == 0
        directory = b/name/f"batch-{row['batch']:04d}"
        xml = ET.parse(directory/'junit.xml').getroot()
        suites = [xml] if xml.tag=='testsuite' else xml.findall('testsuite')
        actual = {key:sum(int(s.get(key,'0')) for s in suites)
                  for key in ('tests','failures','errors','skipped')}
        assert actual == row['counts'] and actual['tests'] == len(row['nodes'])
        assert actual['failures'] == actual['errors'] == 0
        log = (directory/'worker.log').read_text(encoding='utf-8')
        assert re.search(r'\b\d+ (?:passed|skipped|xfailed)\b.*in [\d.]+s',log)
        assert not re.search(r'^FAILED |^ERROR ',log,re.M)
        counts.update(actual)
        seen.extend(row['nodes'])
        evidence.append({'collection':name,'batch':row['batch'],'counts':actual,'nodes':row['nodes']})
assert len(seen) == len(set(seen)) == len(manifest['nodes']) == manifest['collected']
assert set(seen) == set(manifest['nodes'])
result = {'schema_version':1,'complete':True,'source_digest':manifest['source_digest'],
          'collected':len(seen),'counts':dict(counts),'batches':evidence,
          'scope':'complete Windows CPU suite; source-stable partitions; interrupted unverified attempts excluded'}
(b/'full-suite-audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print('FULL SUITE:',counts['tests']-counts['skipped'],'passed,',counts['skipped'],
      'skipped;',len(evidence),'passing batches;',len(seen),'of',len(manifest['nodes']),'IDs verified')
